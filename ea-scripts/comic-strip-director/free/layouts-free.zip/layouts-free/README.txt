Comicbook Strip Director — FREE Panel Layouts
=============================================
30 blank comic-page templates in SVG (vector, infinitely scalable) and PNG.
Use them in ANY tool that imports images: Google Drawings, Miro, Figma,
PowerPoint, Canva, Illustrator, Excalidraw — drop a template in, then fill the
panels with characters and FX.

- svg/  — vector templates (best for scaling / editing panel borders)
- png/  — 1200–1600px raster templates (drop-in ready)

Free to use in your own comics, commercial or personal. Enjoy!
— Iwan Hoogendoorn
